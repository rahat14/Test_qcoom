#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/*** Created by Rahat Shovo on ${DATE} 
*/
#parse("File Header.java")
public class ${NAME} extends RecyclerView.Adapter<${NAME}.${VIEWHOLDER_CLASS}> {
    
    private final Context context;
    private List<${ITEM_CLASS}> items;
     private ItemClickListener itemClickListener;
   
    public ${NAME}(List<${ITEM_CLASS}> items, Context context, ItemClickListener itemClickListener) {
        this.items = items;
        this.context = context;
        this.itemClickListener = itemClickListener;
    }

    @Override
    public @NotNull ${VIEWHOLDER_CLASS} onCreateViewHolder(@NonNull ViewGroup parent,
                                             int viewType) {
        #set( $regex = "([a-z])([A-Z]+)")
        #set( $replacement = "$1_$2")
        #set( $toDash = $VIEWHOLDER_CLASS.replaceAll($regex, $replacement).toLowerCase())                                     
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.${ROW_ITEM_NAME}, parent, false);
        return new ${VIEWHOLDER_CLASS}(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ${VIEWHOLDER_CLASS} holder, int position) {
        ${ITEM_CLASS} item = items.get(position);
        
        holder.itemView.setOnClickListener(v -> {
            itemClickListener.onItemClick(item);
        }) ; 

    }

    

    @Override
    public int getItemCount() {
        if (items == null){
            return 0;
        }
        return items.size();
    }
    
    class ${VIEWHOLDER_CLASS} extends RecyclerView.ViewHolder {

        ${VIEWHOLDER_CLASS}(@NonNull View itemView ) {
            super(itemView);
        }

        
    }

    public interface ItemClickListener {
        void onItemClick(${ITEM_CLASS} model);
    }
    
   
   
 }